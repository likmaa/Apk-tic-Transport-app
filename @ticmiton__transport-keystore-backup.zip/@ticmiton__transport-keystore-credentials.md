# Android Upload Keystore Credentials

These credentials are used in conjunction with your Android upload keystore file to sign your app for distribution.

## Credential Values

- Android upload keystore password: c612881b9d5508d33e859f1d76a66dea
- Android key alias: 6a5921521341a5c05d304ea2388f281a
- Android key password: 0cec27c4e46eea2abcfed8d04b65cb89
      